<?php
//Lista de participantes para ganar el premio de superhéroe/superheroína del año.
$participantes = array(
  1 => array(
    'nombre' => 'Clark Kent',
    'imagen_url' => './img/Henry_Cavill_by_Gage_Skidmore_2.jpg',
  ),
  2 => array(
    'nombre' => 'Bruce Wayne',
    'imagen_url' => './img/Christianbale.jpg',
  ),
  3 => array(
    'nombre' => 'Diana Prince',
    'imagen_url' => './img/Diana_in_White.png',
  ),
  4 => array(
    'nombre' => 'Barry Allen',
    'imagen_url' => './img/Barry-Hallen.png',
  ),
  5 => array(
    'nombre' => 'Hal Jordan',
    'imagen_url' => './img/HalJordan.jpg',
  ),
  6 => array(
    'nombre' => 'Linda Danvers',
    'imagen_url' => './img/LindaDanvers.jpeg',
  ),
  7 => array(
    'nombre' => 'Felicia Hardy',
    'imagen_url' => './img/FeliciaHardy.jpg',
  ),
  8 => array(
    'nombre' => 'Peter Parker',
    'imagen_url' => './img/PeterParker.jpg',
  ),
);