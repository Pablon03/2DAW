<?php

require_once './app/iniciador.php';
require_once './app/autoload.php';
