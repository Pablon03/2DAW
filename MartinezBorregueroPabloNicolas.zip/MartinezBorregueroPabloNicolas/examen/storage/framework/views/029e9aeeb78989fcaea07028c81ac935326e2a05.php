

<?php $__env->startSection('title', 'Mostrar Alumnos'); ?>

<?php $__env->startSection('content'); ?>
<h1>Listado de alumnos</h1>

<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($alumno->nombre); ?></td>
                <td><?php echo e($alumno->apellidos); ?></td>
                <td><?php echo e($alumno->email); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<h2>Añadir nuevo alumno</h2>

<form method="POST" action="<?php echo e(route('agregar', $modulo->id)); ?>">
    <?php echo csrf_field(); ?>
    <div>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
    </div>
    <div>
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required>
    </div>
    <div>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
    </div>
    <button type="submit">Añadir alumno</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\github\2daw\MartinezBorregueroPabloNicolasLaravel\examen\resources\views/modulos/alumnos.blade.php ENDPATH**/ ?>